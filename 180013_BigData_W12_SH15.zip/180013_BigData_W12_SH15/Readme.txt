Employee Table schema Description:

S.No	Column Name	Datatype

1.	emp_id		INT
2.	birthday	String
3.	first_name	String
4. 	last_name	String
5. 	gender     	varchar(5)
6.	work_day	String



Salary Table Schema Description:

S.NO	Column Name	Datatype

1.	emp_id		INT
2.	salary		String
3.	start_date	String
4.	end_date	String